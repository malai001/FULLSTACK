function Appctrl($scope,$http){
	console.log("Hello world from controller")
	$http.get('/contactlist').success(function(response){
		console.log('Got Data');
		$scope.contactlist = response;
	});
	
}