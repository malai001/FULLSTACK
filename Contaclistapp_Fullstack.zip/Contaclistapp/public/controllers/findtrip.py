a = [8,5,1,2,3,4,6]
l = 0
h = len(a)-1
m = 1
for i in range(0,len(a)):
	l += 1
	h -= 1 
	for j in range(0,len(a)):
		if(j == l or h == l):
			j +=1
		else:
			print a[j]