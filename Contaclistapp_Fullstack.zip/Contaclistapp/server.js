var express  =require('express');
var app = express();

app.use(express.static(__dirname + "/public"));
app.get('/contactlist', function(req,res){
	console.log('GET Request')
	person1 = {
		name: 'Anna',
		email: 'annamalai@gmail.com',
		phone: '90036389'
	};
	person2 = {
		name: 'Jon',
		email: 'Jon@gmail.com',
		phone: '1233'
	};
	person3 = {
		name: 'Max',
		email: 'max@gmail.com',
		phone: '4566'
	};
	var contactlist = [person1,person2,person3];
	res.json(contactlist);
});

app.listen(3000);
console.log("Server running on port 3000");